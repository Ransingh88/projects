export default [
    {
        "img":"https://d2aq6dqxahe4ka.cloudfront.net/themes/front/page/images/home-page/Homepage-Banner_Oxygen-Cylinder.jpg",
        "text":'Make breathing easier. Donate oxygen cylinders & Covid-19 essentials.'
    },
    {
        "img":"https://d2aq6dqxahe4ka.cloudfront.net/themes/front/page/images/home-page/Homepage-Banner_Help-Nurse.jpg",
        "text":'There is 1 nurse for every 670 of us. Donate now to bridge this gap.'
    },
    {
        "img":"https://d2aq6dqxahe4ka.cloudfront.net/themes/front/images/Teera.jpg",
        "text":"Record-breaking! ₹14.92 Cr. raised for Teera's fight against a rare disease."
    },
    {
        "img":"https://d2aq6dqxahe4ka.cloudfront.net/themes/front/page/images/home-page/0-Intrest-Banner-Final.jpg",
        "text":'With a 0% platform fee, receive maximum funds for your cause.'
    },
    {
        "img":"https://d2aq6dqxahe4ka.cloudfront.net/themes/front/page/images/home-page/Amit-Shenoy.jpg",
        "text":'Amit Shenoy raised ₹45 Lakh for his blood cancer treatment.'
    }
];